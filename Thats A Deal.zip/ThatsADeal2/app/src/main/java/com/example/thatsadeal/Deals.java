package com.example.thatsadeal;

import com.parse.ParseClassName;
import com.parse.ParseObject;

@ParseClassName("Deals")

public class Deals extends ParseObject {


    public static final String KEY_NAME= "rName";
    public static final String KEY_DEAL = "Deal";
    public static final String KEY_EXPDATE = "ExpirationDate";

    public String getName() {
        return getString(KEY_NAME);
    }

    public void setName(String name){
        put(KEY_NAME, name);
    }

    public String getDeal() {
        return getString(KEY_DEAL);
    }
    public void setDeal(String address){
        put(KEY_DEAL, address);
    }

    public String getExpDate() {
        return getString(KEY_EXPDATE);
    }
    public void setExpDate(String phoneNumber){
        put(KEY_EXPDATE, phoneNumber);
    }

}
