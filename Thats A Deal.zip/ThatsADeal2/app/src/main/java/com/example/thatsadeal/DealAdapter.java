package com.example.thatsadeal;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class DealAdapter extends RecyclerView.Adapter<DealAdapter.ViewHolder> {
    private Context context;
    private List<Deals> deals;

    public DealAdapter(Context context, List<Deals> deals){

        this.context = context;
        this.deals = deals;
    }

    @NonNull
    @Override
    public DealAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.restaurant_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull DealAdapter.ViewHolder holder, int position) {
        Deals deal = deals.get(position);
        //Restaurant r = new Restaurant();
        holder.bind(deal);
    }

    public void clear(){
        deals.clear();
        notifyDataSetChanged();
    }

    public void addAll(List<Deals> deal){
        deals.addAll(deal);
        notifyDataSetChanged();
    }

    @Override
    public int getItemCount() {
        return deals.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder{
        private TextView txtName;
        private TextView txtDeal;
        private TextView txtExpDate;
        public ViewHolder(@NonNull View itemView){
            super(itemView);

            txtName = itemView.findViewById(R.id.txtName);
            txtDeal = itemView.findViewById(R.id.txtDeal);
            txtExpDate = itemView.findViewById(R.id.txtExpDate);
        }

        public void bind(Deals deals){
            txtName.setText(deals.getName());
            txtDeal.setText(deals.getDeal());
            txtExpDate.setText(deals.getExpDate());
        }
    }
}
