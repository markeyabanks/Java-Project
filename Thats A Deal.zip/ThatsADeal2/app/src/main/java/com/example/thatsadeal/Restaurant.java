package com.example.thatsadeal;

import com.parse.ParseClassName;
import com.parse.ParseObject;

@ParseClassName("Restaurants")

public class Restaurant extends ParseObject {


    public static final String KEY_NAME= "Name";
    public static final String KEY_ADDRESS = "Address";
    public static final String KEY_PHONENUMBER = "PhoneNumber";


    public String getName() {
        return getString(KEY_NAME);
    }

    public void setName(String name){
        put(KEY_NAME, name);
    }

    public String getAddress() {
        return getString(KEY_ADDRESS);
    }
    public void setAddress(String address){
        put(KEY_ADDRESS, address);
    }

    public String getPhoneNumber() {
        return getString(KEY_PHONENUMBER);
    }
    public void setPhoneNumber(String phoneNumber){
        put(KEY_PHONENUMBER, phoneNumber);
    }
    public String getKeyObjid(){
        return getObjectId();
    }


}
